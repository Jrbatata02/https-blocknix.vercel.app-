import { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import './App.css';

export default function App() {
  const [account, setAccount] = useState(null);

  async function connectWallet() {
    if (window.ethereum) {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setAccount(accounts[0]);
    }
  }

  return (
    <div className="app">
      <img src="/logo.png" alt="Blocknix Logo" style={{ width: 100, borderRadius: '50%' }} />
      <h1>Blocknix Staking DApp</h1>
      <button onClick={connectWallet}>
        {account ? `Conectado: ${account.slice(0, 6)}...` : 'Conectar MetaMask'}
      </button>
    </div>
  );
}
